//
//  KS3PutObjectCopyResponse.h
//  KSYSDKDemo
//
//  Created by Blues on 12/25/14.
//  Copyright (c) 2014 kingsoft. All rights reserved.
//

#import "KS3Response.h"

@interface KS3PutObjectCopyResponse : KS3Response

@end
