//
//  KSS3SetGrantACLResponse.h
//  KS3iOSSDKDemo
//
//  Created by Blues on 12/18/14.
//  Copyright (c) 2014 Blues. All rights reserved.
//

#import "KS3Response.h"

@interface KS3SetGrantACLResponse : KS3Response

@end
