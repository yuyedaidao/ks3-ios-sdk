//
//  KSS3DeleteObjectResponse.h
//  KS3SDK
//
//  Created by JackWong on 12/14/14.
//  Copyright (c) 2014 kingsoft. All rights reserved.
//

#import "KS3Response.h"

@interface KS3DeleteObjectResponse : KS3Response

@end
