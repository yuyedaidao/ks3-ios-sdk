//
//  KSS3DeleteBucketResponse.h
//  KS3SDK
//
//  Created by JackWong on 12/10/14.
//  Copyright (c) 2014 kingsoft. All rights reserved.
//

#import "KS3Response.h"

@interface KS3DeleteBucketResponse : KS3Response


@end
