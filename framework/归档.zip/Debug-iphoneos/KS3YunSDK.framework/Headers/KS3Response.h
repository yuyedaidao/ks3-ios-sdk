//
//  S3Response.h
//  KS3SDK
//
//  Created by JackWong on 12/9/14.
//  Copyright (c) 2014 kingsoft. All rights reserved.
//
#import "KS3ServiceResponse.h"
@interface KS3Response : KS3ServiceResponse
@end
