//
//  KSS3SetObjectGrantACLResponse.h
//  KS3iOSSDKDemo
//
//  Created by Blues on 12/18/14.
//  Copyright (c) 2014 Blues. All rights reserved.
//

#import "KS3Response.h"

@interface KS3SetObjectGrantACLResponse : KS3Response

@end
