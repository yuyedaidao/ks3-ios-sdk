//
//  KSS3HeadBucketResponse.h
//  KS3YunSDK
//
//  Created by Blues on 12/18/14.
//  Copyright (c) 2014 kingsoft. All rights reserved.
//

#import "KS3Response.h"

@interface KS3HeadBucketResponse : KS3Response

@end
